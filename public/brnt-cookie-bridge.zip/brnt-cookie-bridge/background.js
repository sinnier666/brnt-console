// BRNT Cookie Bridge - background service worker (MV3, module).
// Handles one-click automation requests coming from the BRNT LoginProbe console
// via chrome.runtime.sendMessage (allowed origins are declared in manifest.json
// under "externally_connectable").

import { parseCookieText, buildSetAttempts, decodeMagicToken } from './shared.js';

function senderAllowed(url) {
  try {
    const u = new URL(url);
    if (u.protocol === 'https:') {
      return u.hostname === 'space-z.ai' || u.hostname.endsWith('.space-z.ai');
    }
    if (u.protocol === 'http:') {
      return (u.hostname === 'localhost' || u.hostname === '127.0.0.1') && u.port === '3000';
    }
  } catch {
    /* ignore */
  }
  return false;
}

async function applyCookies(baseUrl, cookies) {
  const results = { set: 0, failed: [] };
  for (const c of cookies) {
    let done = false;
    let lastErr = null;
    for (const details of buildSetAttempts(c, baseUrl)) {
      try {
        const r = await chrome.cookies.set(details);
        if (r) {
          done = true;
          break;
        }
        lastErr = new Error('chrome.cookies.set returned null');
      } catch (e) {
        lastErr = e;
      }
    }
    if (done) {
      results.set++;
    } else {
      results.failed.push({ name: c.name, error: String(lastErr ? lastErr.message : 'unknown error') });
    }
  }
  return results;
}

chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (!sender.url || !senderAllowed(sender.url)) return;

  if (msg && msg.type === 'BRNT_PING') {
    sendResponse({
      ok: true,
      name: 'BRNT Cookie Bridge',
      version: chrome.runtime.getManifest().version,
    });
    return;
  }

  if (msg && msg.type === 'BRNT_APPLY') {
    (async () => {
      try {
        let baseUrl = String(msg.url || '');
        if (!/^https?:\/\//i.test(baseUrl)) baseUrl = 'https://' + baseUrl;
        const u = new URL(baseUrl);
        if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('http(s) URL required');

        let cookies = [];
        if (Array.isArray(msg.cookies)) {
          cookies = msg.cookies;
        } else if (typeof msg.cookies === 'string' && msg.cookies.trim()) {
          cookies = parseCookieText(msg.cookies).cookies;
        }
        if (!cookies.length) throw new Error('no cookies provided');

        const res = await applyCookies(u.origin + '/', cookies);
        if (msg.open !== false) {
          await chrome.tabs.create({ url: u.href, active: true });
        }
        sendResponse({ ok: res.failed.length === 0, ...res });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // async response
  }
});

// ---------- Magic links: ?nftoken= / ?brnttoken= ----------
// A link like https://netflix.com/?nftoken=BR1.… carries the session cookies.
// When it is opened in any tab, the Bridge applies the cookies to the site,
// strips the parameter and reloads — landing the user logged-in on the real site.

const MAGIC_PARAMS = ['nftoken', 'brnttoken'];
const recentMagic = new Map(); // tabId -> { url, ts }

function magicTokenIn(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    for (const p of MAGIC_PARAMS) {
      const t = u.searchParams.get(p);
      if (t) return { token: t, u };
    }
  } catch {
    /* not a URL */
  }
  return null;
}

async function handleMagicNavigation(tabId, navUrl) {
  const found = magicTokenIn(navUrl);
  if (!found) return;

  // dedupe onBeforeNavigate + onCommitted for the same URL
  const prev = recentMagic.get(tabId);
  if (prev && prev.url === navUrl && Date.now() - prev.ts < 10000) return;
  recentMagic.set(tabId, { url: navUrl, ts: Date.now() });

  try {
    const payload = await decodeMagicToken(found.token);
    if (!payload) throw new Error('invalid or empty nftoken payload');

    const baseUrl = payload.u || found.u.origin + '/';
    const res = await applyCookies(baseUrl, payload.c);

    const clean = new URL(found.u.href);
    for (const p of MAGIC_PARAMS) clean.searchParams.delete(p);
    let cleanHref = clean.href;
    if (cleanHref.endsWith('?')) cleanHref = cleanHref.slice(0, -1);

    await chrome.tabs.update(tabId, { url: cleanHref });

    try {
      await chrome.action.setBadgeBackgroundColor({
        tabId,
        color: res.failed.length ? '#f43f5e' : '#10b981',
      });
      await chrome.action.setBadgeText({ tabId, text: res.failed.length ? 'ERR' : 'OK' });
      setTimeout(() => {
        chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});
      }, 5000);
    } catch {
      /* badge is cosmetic */
    }
    console.log(`[BRNT] magic link: applied ${res.set}/${payload.c.length} cookies -> ${cleanHref}`);
    if (res.failed.length) {
      console.warn('[BRNT] magic link failures:', res.failed);
    }
  } catch (e) {
    console.warn('[BRNT] magic link failed:', e && e.message ? e.message : e);
  }
}

chrome.webNavigation.onBeforeNavigate.addListener((d) => {
  if (d.frameId === 0) handleMagicNavigation(d.tabId, d.url);
});
chrome.webNavigation.onCommitted.addListener((d) => {
  if (d.frameId === 0) handleMagicNavigation(d.tabId, d.url);
});
