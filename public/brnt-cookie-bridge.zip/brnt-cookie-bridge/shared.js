// BRNT Cookie Bridge - shared cookie parsing + chrome.cookies.set helpers.
// Pure JavaScript, no chrome.* calls in the parsers so it can be unit-tested with bun/node.

// ---------- Public API ----------

/**
 * Parse cookie text in any common format.
 * Supported: Netscape cookies.txt, Cookie-Editor JSON array, JSON object map,
 * JSONL (one JSON object per line), header string (name=value; name2=value2).
 * @param {string} raw
 * @returns {{format: string|null, cookies: Array<object>}}
 */
export function parseCookieText(raw) {
  const t = String(raw == null ? '' : raw).trim();
  if (!t) return { format: null, cookies: [] };

  if (t[0] === '[' || t[0] === '{') {
    try {
      const j = JSON.parse(t);
      const parsed = parseJsonCookies(j);
      if (parsed.length) return { format: 'JSON', cookies: parsed };
    } catch {
      /* fall through */
    }
  }

  const nc = parseNetscape(t);
  if (nc.length) return { format: 'Netscape cookies.txt', cookies: nc };

  const hc = parseHeaderCookies(t);
  if (hc.length) return { format: 'header (name=value; ...)', cookies: hc };

  return { format: null, cookies: [] };
}

/**
 * Derive the most likely site URL from parsed cookies (most specific domain wins).
 * @param {Array<object>} cookies
 * @returns {string|null} e.g. "https://www.primevideo.com/"
 */
export function deriveSiteUrl(cookies) {
  const hosts = [
    ...new Set(
      (cookies || [])
        .filter((c) => c.domain)
        .map((c) => c.domain.replace(/^\./, '').toLowerCase())
        .filter((h) => h.includes('.'))
    ),
  ];
  if (!hosts.length) return null;
  hosts.sort((a, b) => b.length - a.length);
  return 'https://' + hosts[0] + '/';
}

/** Normalize user-entered URL: add https:// when scheme missing, validate. */
export function normalizeUrl(v) {
  let s = String(v || '').trim();
  if (!s) throw new Error('URL is empty');
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  const u = new URL(s);
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('Only http(s) URLs are supported');
  return u.href;
}

/** Map sameSite values from various exporters to chrome.cookies values. */
export function mapSameSite(v) {
  const s = String(v == null ? '' : v).toLowerCase();
  if (s === 'no_restriction' || s === 'none') return 'no_restriction';
  if (s === 'lax') return 'lax';
  if (s === 'strict') return 'strict';
  return null; // unspecified
}

/**
 * Build an ordered list of chrome.cookies.set() detail objects for one cookie,
 * from most complete to most minimal (progressive fallback).
 * @param {object} c parsed cookie
 * @param {string} baseUrl target site URL (normalized)
 * @returns {Array<object>} unique attempts
 */
export function buildSetAttempts(c, baseUrl) {
  const u = new URL(baseUrl);
  const host = (c.domain ? c.domain.replace(/^\./, '') : u.hostname).toLowerCase();
  const secure = c.secure === true || u.protocol === 'https:';
  const scheme = u.protocol === 'https:' || secure ? 'https' : 'http';
  const path = c.path || '/';
  const url = `${scheme}://${host}${path}`;

  const base = { url, name: c.name, value: c.value == null ? '' : String(c.value) };
  const exp = Number(c.expirationDate);
  const ss = mapSameSite(c.sameSite);

  const full = { ...base, path, secure, httpOnly: !!c.httpOnly };
  if (c.domain) full.domain = c.domain;
  if (exp > 0) full.expirationDate = exp;
  if (ss) full.sameSite = ss;

  const noSS = { ...full };
  delete noSS.sameSite;
  const noFlags = { ...noSS };
  delete noFlags.httpOnly;
  const hostOnly = { ...base, path, secure };
  if (exp > 0) hostOnly.expirationDate = exp;
  const minimal = { ...base };

  const attempts = [full, noSS, noFlags, hostOnly, minimal];
  const seen = new Set();
  return attempts.filter((a) => {
    const k = JSON.stringify(a);
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

// ---------- Magic links (nftoken) ----------

// Tokens look like: BR1.<base64url(deflate-raw(JSON))> or BR0.<base64url(JSON)>
// JSON shape: { v: 1, u: "https://site/…", c: [{ n, v, d?, p?, s?, h?, ss?, e? }] }

function b64urlToBytes(s) {
  let b64 = String(s).replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

/**
 * Decode an nftoken/brnttoken payload into { v, u, c:[cookie…] }.
 * Cookie objects are expanded to the same shape parseCookieText() emits,
 * so buildSetAttempts() can consume them directly.
 * @param {string} token raw query-param value
 * @returns {Promise<object|null>} payload or null when invalid
 */
export async function decodeMagicToken(token) {
  const m = /^BR([01])\.([A-Za-z0-9\-_]+)$/.exec(String(token == null ? '' : token).trim());
  if (!m) return null;
  let jsonText;
  const bytes = b64urlToBytes(m[2]);
  if (m[1] === '1') {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('DecompressionStream unsupported in this browser');
    }
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([bytes]).stream().pipeThrough(ds);
    jsonText = new TextDecoder().decode(await new Response(stream).arrayBuffer());
  } else {
    jsonText = new TextDecoder().decode(bytes);
  }
  const p = JSON.parse(jsonText);
  if (!p || typeof p !== 'object' || !Array.isArray(p.c) || !p.c.length) return null;
  const cookies = [];
  for (const c of p.c) {
    if (!c || typeof c.n !== 'string' || typeof c.v !== 'string') continue;
    const out = { name: c.n, value: c.v };
    if (c.d) out.domain = c.d;
    if (c.p) out.path = c.p;
    if (c.s) out.secure = true;
    if (c.h) out.httpOnly = true;
    if (c.ss) out.sameSite = c.ss;
    const exp = Number(c.e);
    if (Number.isFinite(exp) && exp > 0) out.expirationDate = exp;
    cookies.push(out);
  }
  if (!cookies.length) return null;
  return { v: Number(p.v) || 1, u: typeof p.u === 'string' && p.u ? p.u : null, c: cookies };
}

// ---------- Format parsers ----------

function parseNetscape(t) {
  const out = [];
  for (let line of t.split(/\r?\n/)) {
    line = line.trim();
    if (!line) continue;
    let httpOnly = false;
    if (line.startsWith('#HttpOnly_')) {
      httpOnly = true;
      line = line.slice('#HttpOnly_'.length);
    } else if (line.startsWith('#')) {
      continue;
    }
    let parts = line.split('\t');
    if (parts.length < 7) parts = line.split(/\s+/);
    if (parts.length < 7) continue;
    const [domain, , path, secure, expires, name, ...valueRest] = parts;
    if (!name) continue;
    const cookie = {
      name,
      value: valueRest.join('\t'),
      path: path || '/',
      secure: String(secure).toUpperCase() === 'TRUE',
      httpOnly,
    };
    if (domain) cookie.domain = domain;
    const exp = parseInt(expires, 10);
    if (exp > 0) cookie.expirationDate = exp;
    out.push(cookie);
  }
  return out;
}

function parseJsonCookies(j) {
  const norm = (o) => {
    if (!o || typeof o !== 'object' || !o.name) return null;
    const c = {
      name: String(o.name),
      value: o.value == null ? '' : String(o.value),
    };
    if (o.domain) c.domain = String(o.domain);
    if (o.path) c.path = String(o.path);
    if (o.secure != null) c.secure = !!o.secure;
    if (o.httpOnly != null) c.httpOnly = !!o.httpOnly;
    if (o.sameSite) c.sameSite = String(o.sameSite);
    let exp = Number(o.expirationDate != null ? o.expirationDate : o.expires);
    if (Number.isFinite(exp) && exp > 1e12) exp = exp / 1000; // ms -> s
    if (exp > 0) c.expirationDate = exp;
    if (o.session === true) c.expirationDate = undefined;
    return c;
  };
  if (Array.isArray(j)) {
    return j.map(norm).filter(Boolean);
  }
  if (j && typeof j === 'object') {
    // single cookie object
    if (j.name) {
      const one = norm(j);
      return one ? [one] : [];
    }
    // map form: {name: value, ...}
    return Object.entries(j)
      .filter(([k]) => k && typeof k === 'string')
      .map(([k, v]) => ({ name: k, value: v == null ? '' : String(v) }));
  }
  return [];
}

function parseHeaderCookies(t) {
  const out = [];
  const seen = new Set();
  for (const piece of t.split(/[;\n]+/)) {
    const p = piece.trim();
    if (!p) continue;
    const eq = p.indexOf('=');
    if (eq <= 0) continue;
    const name = p.slice(0, eq).trim();
    const value = p.slice(eq + 1).trim();
    if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name)) continue;
    const key = name + '=' + value;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ name, value });
  }
  return out;
}
