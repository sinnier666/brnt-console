// BRNT Cookie Bridge - shared cookie parsing + chrome.cookies.set helpers.
// Pure JavaScript, no chrome.* calls in the parsers so it can be unit-tested with bun/node.

// ---------- Public API ----------

/**
 * Find an nftoken/brntoken magic token inside arbitrary pasted text (e.g. a
 * full URL like https://netflix.com/browse?nftoken=BR1.xxx, possibly
 * line-wrapped by messengers — whitespace is stripped before matching).
 * Only returns BRNT-format tokens (BR0./BR1.). Native Netflix tokens are
 * detected separately by extractNativeLink().
 * @param {string} text
 * @returns {string|null} the token (e.g. "BR1.xxxx") or null
 */
export function extractMagicToken(text) {
  const flat = String(text == null ? '' : text).replace(/\s+/g, '');
  if (!/(nftoken|brntoken)=/i.test(flat)) return null;
  const m = /(?:nftoken|brntoken)=([A-Za-z0-9\-_.]+)/i.exec(flat);
  if (!m) return null;
  return /^BR[01]\.[A-Za-z0-9\-_]+$/.test(m[1]) ? m[1] : null;
}

/**
 * Detect a NATIVE Netflix login link (?nftoken=<raw token> minted by
 * Netflix's own iOS API / web flows). These carry no BR0./BR1. prefix, they
 * contain "+"/"/" base64 characters, and they must NOT be decoded here:
 * Netflix's own server validates them and signs the visitor in. The popup
 * uses this to tell the user "no extension needed - just open the link".
 * @param {string} text
 * @returns {{token: string, url: string}|null}
 */
export function extractNativeLink(text) {
  const flat = String(text == null ? '' : text).replace(/\s+/g, '');
  if (!/(nftoken|brntoken)=/i.test(flat)) return null;
  const tm = /(?:nftoken|brntoken)=([^&#]+)/i.exec(flat);
  if (!tm) return null;
  const token = tm[1];
  if (/^BR[01]\./.test(token)) return null; // ours — handled by the decode path
  if (token.length < 32) return null; // too short to be a session token
  const um = /https?:\/\/[^&]+/i.exec(flat);
  const url = um ? um[0] : 'https://netflix.com/?nftoken=' + encodeURIComponent(token);
  return { token, url };
}

/**
 * Clean a cookie value so chrome.cookies.set can accept it. Chrome rejects
 * values containing ";" (RFC 6265 cookie-octet), surrounding quotes and
 * stray whitespace — mangled hand-built exports often carry all three.
 * @param {string} v
 * @returns {string}
 */
export function sanitizeCookieValue(v) {
  let s = String(v == null ? '' : v).trim();
  const semi = s.indexOf(';');
  if (semi >= 0) s = s.slice(0, semi); // glued second pair / trailing attributes
  s = s.trim();
  if (s.length > 1 && s[0] === '"' && s[s.length - 1] === '"') s = s.slice(1, -1);
  return s;
}

/**
 * Parse "name=value; name2=value2" fragments out of garbage fields (e.g. a
 * whole cookie pair pasted into the JSON "domain" field). Returns clean
 * {name, value} pairs; junk segments are skipped.
 * @param {string} s
 * @returns {Array<{name: string, value: string}>}
 */
export function salvagePairsFromGarbage(s) {
  const out = [];
  for (const piece of String(s == null ? '' : s).split(';')) {
    const p = piece.trim();
    if (!p) continue;
    const eq = p.indexOf('=');
    if (eq <= 0) continue;
    const name = p.slice(0, eq).trim();
    if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name)) continue;
    out.push({ name, value: sanitizeCookieValue(p.slice(eq + 1)) });
  }
  return out;
}

/**
 * Pull the value out of "Cookie:" / "Set-Cookie:" header lines (DevTools
 * request-header copies). Set-Cookie keeps only name=value (attributes are
 * applied separately by the cookie jar, and they would confuse the plain
 * header parser).
 * @param {string} text
 * @returns {string} a plain "name=value; name2=value2" string (may be empty)
 */
function extractCookieHeaderLines(text) {
  const out = [];
  let open = false; // last line was a "cookie:" entry that may continue (obs-fold)
  for (const line of String(text || '').split(/\r?\n/)) {
    const m = /^\s*(set-)?cookie2?\s*:\s*(.*)$/i.exec(line);
    if (m) {
      const isSet = Boolean(m[1]);
      let v = m[2].trim();
      if (isSet) v = v.split(';')[0].trim(); // attributes are not wanted here
      out.push(v);
      open = !isSet;
      continue;
    }
    if (open && /^[ \t]+\S/.test(line) && out.length) {
      // folded header continuation (line starts with whitespace)
      out[out.length - 1] += (out[out.length - 1] ? ' ' : '') + line.trim();
    }
  }
  return out.filter(Boolean).join('; ');
}

/**
 * Parse cookie text in any common format.
 * Supported: Netscape cookies.txt, Cookie-Editor JSON array, JSON object map,
 * JSONL (one JSON object per line), header string (name=value; name2=value2),
 * DevTools "Cookie:" / "Set-Cookie:" header lines.
 * @param {string} raw
 * @returns {{format: string|null, cookies: Array<object>}}
 */
export function parseCookieText(raw) {
  const t = String(raw == null ? '' : raw).trim();
  if (!t) return { format: null, cookies: [] };

  if (t[0] === '[' || t[0] === '{') {
    try {
      const j = JSON.parse(t);
      const parsed = parseJsonCookies(j);
      if (parsed.length) return { format: 'JSON', cookies: parsed };
    } catch {
      /* fall through */
    }
  }

  const nc = parseNetscape(t);
  if (nc.length) return { format: 'Netscape cookies.txt', cookies: nc };

  const hdrLines = extractCookieHeaderLines(t);
  const hc = parseHeaderCookies(hdrLines || t);
  if (hc.length) {
    return {
      format: hdrLines ? 'header lines (Cookie: ...)' : 'header (name=value; ...)',
      cookies: hc,
    };
  }

  return { format: null, cookies: [] };
}

/**
 * True when d looks like a real hostname (no '=', '%', spaces, etc.).
 * Malformed cookie exports sometimes carry "name=value" strings in the
 * domain field; those must never reach chrome.cookies.set or the site field.
 * @param {string|undefined} d
 * @returns {boolean}
 */
export function looksLikeDomain(d) {
  const s = String(d == null ? '' : d).trim().replace(/^\./, '').toLowerCase();
  if (!s) return false;
  if (s === 'localhost') return true;
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(s);
}

/**
 * Derive the most likely site URL from parsed cookies (most specific domain wins).
 * @param {Array<object>} cookies
 * @returns {string|null} e.g. "https://www.primevideo.com/"
 */
export function deriveSiteUrl(cookies) {
  const hosts = [
    ...new Set(
      (cookies || [])
        .filter((c) => c.domain)
        .map((c) => c.domain.replace(/^\./, '').toLowerCase())
        .filter((h) => looksLikeDomain(h))
    ),
  ];
  if (!hosts.length) return null;
  hosts.sort((a, b) => b.length - a.length);
  return 'https://' + hosts[0] + '/';
}

/**
 * v1.6.0 "use the current page" targeting — there is no manual site field
 * anymore. Resolve which site the popup should import the cookies into,
 * based on the ACTIVE TAB and the cookies themselves.
 *
 * Decision table (first match wins):
 *  1. A decoded magic link carries its own URL -> that URL is the target.
 *  2. Active tab is a normal http(s) page AND its host matches one of the
 *     cookie domains (or the cookies carry no domain at all) -> the current
 *     tab IS the target (one click sets cookies + reloads in place).
 *  3. Active tab is http(s) but clearly a different site -> fall back to the
 *     domain derived from the cookies and open it in a new tab.
 *  4. Active tab is not a website (chrome://, new tab, ...) -> derived site
 *     in a new tab; without any cookie domain there is nothing to go on.
 *
 * @param {object} opts
 * @param {string|null} opts.magicUrl      target URL from a decoded magic link (''/null when none)
 * @param {string|null} opts.activeTabUrl  URL of the active tab ('' when none / not http)
 * @param {Array<object>} opts.cookies     parsed cookies (same shape as parseCookieText)
 * @returns {{url: string|null, mode: 'current-tab'|'new-tab', matched: boolean, reason: string}}
 *   url    – absolute target URL (origin + '/'), null when unresolvable
 *   mode   – 'current-tab' = reload the active tab after applying,
 *            'new-tab'     = open url in a new tab after applying
 *   matched– true when the active tab itself is the target site
 *   reason – short human-readable explanation for the popup status line
 */
export function resolveImportTarget({ magicUrl, activeTabUrl, cookies }) {
  const list = Array.isArray(cookies) ? cookies : [];
  const hosts = [
    ...new Set(
      list
        .filter((c) => c && c.domain)
        .map((c) => String(c.domain).replace(/^\./, '').toLowerCase())
        .filter((h) => looksLikeDomain(h))
    ),
  ];

  let tab = null;
  try {
    if (activeTabUrl && /^https?:/i.test(activeTabUrl)) tab = new URL(activeTabUrl);
  } catch {
    /* not a URL — treat as no tab */
  }
  const tabOrigin = tab ? tab.origin + '/' : null;
  const tabHost = tab ? tab.hostname.toLowerCase() : '';

  const hostMatches = (host, domainList) =>
    domainList.some((d) => host === d || host.endsWith('.' + d));

  // 1. magic link URL wins
  if (magicUrl) {
    try {
      const mu = new URL(magicUrl);
      const url = mu.origin + '/';
      if (tab && tab.hostname.toLowerCase() === mu.hostname.toLowerCase()) {
        return { url, mode: 'current-tab', matched: true, reason: 'current tab is the magic-link site' };
      }
      return {
        url,
        mode: 'new-tab',
        matched: false,
        reason: tab ? 'magic-link site differs from the current tab' : 'site from the magic link',
      };
    } catch {
      /* fall through to cookie/tab logic */
    }
  }

  // 2/3. active tab drives the decision
  if (tab) {
    if (!hosts.length || hostMatches(tabHost, hosts)) {
      const why = hosts.length
        ? 'current tab matches the cookie domain'
        : 'cookies carry no domain - they will be set for the current tab';
      return { url: tabOrigin, mode: 'current-tab', matched: true, reason: why };
    }
    const derived = deriveSiteUrl(list);
    if (derived) {
      return {
        url: derived,
        mode: 'new-tab',
        matched: false,
        reason: 'current tab is a different site - cookies go to their own site in a new tab',
      };
    }
    return { url: tabOrigin, mode: 'current-tab', matched: true, reason: 'using the current tab' };
  }

  // 4. no usable active tab
  const derived = deriveSiteUrl(list);
  if (derived) {
    return { url: derived, mode: 'new-tab', matched: false, reason: 'current tab is not a website - opening the cookie site' };
  }
  return {
    url: null,
    mode: 'new-tab',
    matched: false,
    reason: 'no target: open the site in a tab first, or use cookies that carry a domain',
  };
}

/** Normalize user-entered URL: add https:// when scheme missing, validate. */
export function normalizeUrl(v) {
  let s = String(v || '').trim();
  if (!s) throw new Error('URL is empty');
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  const u = new URL(s);
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('Only http(s) URLs are supported');
  if (/[=%;\s]/.test(u.hostname)) throw new Error('not a valid site host');
  return u.href;
}

/** Map sameSite values from various exporters to chrome.cookies values. */
export function mapSameSite(v) {
  const s = String(v == null ? '' : v).toLowerCase();
  if (s === 'no_restriction' || s === 'none') return 'no_restriction';
  if (s === 'lax') return 'lax';
  if (s === 'strict') return 'strict';
  return null; // unspecified
}

/**
 * Build an ordered list of chrome.cookies.set() detail objects for one cookie,
 * from most complete to most minimal (progressive fallback).
 * @param {object} c parsed cookie
 * @param {string} baseUrl target site URL (normalized)
 * @returns {Array<object>} unique attempts
 */
export function buildSetAttempts(c, baseUrl) {
  const u = new URL(baseUrl);
  const domOk = looksLikeDomain(c.domain);
  const host = (domOk ? c.domain.replace(/^\./, '') : u.hostname).toLowerCase();
  const secure = c.secure === true || u.protocol === 'https:';
  const scheme = u.protocol === 'https:' || secure ? 'https' : 'http';
  const path = c.path || '/';
  const url = `${scheme}://${host}${path}`;

  const base = {
    url,
    name: c.name,
    value: sanitizeCookieValue(c.value), // Chrome rejects ";" in values
  };
  const exp = Number(c.expirationDate);
  const ss = mapSameSite(c.sameSite);

  const full = { ...base, path, secure, httpOnly: !!c.httpOnly };
  if (domOk) full.domain = c.domain;
  if (exp > 0) full.expirationDate = exp;
  if (ss) full.sameSite = ss;

  const noSS = { ...full };
  delete noSS.sameSite;
  const noFlags = { ...noSS };
  delete noFlags.httpOnly;
  const hostOnly = { ...base, path, secure };
  if (exp > 0) hostOnly.expirationDate = exp;
  const minimal = { ...base };

  const attempts = [full, noSS, noFlags, hostOnly, minimal];
  const seen = new Set();
  return attempts.filter((a) => {
    const k = JSON.stringify(a);
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

// ---------- Magic links (nftoken) ----------

// Tokens look like: BR1.<base64url(deflate-raw(JSON))> or BR0.<base64url(JSON)>
// JSON shape: { v: 1, u: "https://site/…", c: [{ n, v, d?, p?, s?, h?, ss?, e? }] }

function b64urlToBytes(s) {
  let b64 = String(s).replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

/**
 * Decode an nftoken/brnttoken payload into { v, u, c:[cookie…] }.
 * Cookie objects are expanded to the same shape parseCookieText() emits,
 * so buildSetAttempts() can consume them directly.
 * @param {string} token raw query-param value
 * @returns {Promise<object|null>} payload or null when invalid
 */
export async function decodeMagicToken(token) {
  const m = /^BR([01])\.([A-Za-z0-9\-_]+)$/.exec(String(token == null ? '' : token).trim());
  if (!m) return null;
  let jsonText;
  const bytes = b64urlToBytes(m[2]);
  if (m[1] === '1') {
    if (typeof DecompressionStream === 'undefined') {
      throw new Error('DecompressionStream unsupported in this browser');
    }
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([bytes]).stream().pipeThrough(ds);
    jsonText = new TextDecoder().decode(await new Response(stream).arrayBuffer());
  } else {
    jsonText = new TextDecoder().decode(bytes);
  }
  const p = JSON.parse(jsonText);
  if (!p || typeof p !== 'object' || !Array.isArray(p.c) || !p.c.length) return null;
  const cookies = [];
  for (const c of p.c) {
    if (!c || typeof c.n !== 'string' || typeof c.v !== 'string') continue;
    const out = { name: c.n, value: c.v };
    if (c.d) out.domain = c.d;
    if (c.p) out.path = c.p;
    if (c.s) out.secure = true;
    if (c.h) out.httpOnly = true;
    if (c.ss) out.sameSite = c.ss;
    const exp = Number(c.e);
    if (Number.isFinite(exp) && exp > 0) out.expirationDate = exp;
    cookies.push(out);
  }
  if (!cookies.length) return null;
  return { v: Number(p.v) || 1, u: typeof p.u === 'string' && p.u ? p.u : null, c: cookies };
}

/**
 * Forgiving variant of decodeMagicToken for tokens pasted as free text: when
 * stray characters got glued to the end of the token (e.g. "...XX0end"), it
 * retries progressively shorter candidates until one decodes.
 * @param {string} token
 * @returns {Promise<object|null>} payload or null
 */
export async function decodeMagicTokenSmart(token) {
  const t = String(token == null ? '' : token).trim();
  const tries = [t];
  for (let cut = 1; cut <= 16 && cut < t.length; cut++) tries.push(t.slice(0, -cut));
  for (const cand of tries) {
    if (!/^BR[01]\.[A-Za-z0-9\-_]+$/.test(cand)) continue;
    try {
      const p = await decodeMagicToken(cand);
      if (p) return p;
    } catch {
      /* try the next candidate */
    }
  }
  return null;
}

// ---------- Format parsers ----------

function parseNetscape(t) {
  const out = [];
  for (let line of t.split(/\r?\n/)) {
    line = line.trim();
    if (!line) continue;
    let httpOnly = false;
    if (line.startsWith('#HttpOnly_')) {
      httpOnly = true;
      line = line.slice('#HttpOnly_'.length);
    } else if (line.startsWith('#')) {
      continue;
    }
    let parts = line.split('\t');
    if (parts.length < 7) parts = line.split(/\s+/);
    if (parts.length < 7) continue;
    const [domain, , path, secure, expires, name, ...valueRest] = parts;
    if (!name) continue;
    const cookie = {
      name,
      value: sanitizeCookieValue(valueRest.join('\t')),
      path: path || '/',
      secure: String(secure).toUpperCase() === 'TRUE',
      httpOnly,
    };
    if (domain) cookie.domain = domain;
    const exp = parseInt(expires, 10);
    if (exp > 0) cookie.expirationDate = exp;
    out.push(cookie);
  }
  return out;
}

function parseJsonCookies(j) {
  // Returns an ARRAY per input object: a garbage domain field can carry one
  // cookie pair (the main cookie) or several ("NetflixId=…; SecureNetflixId=…"),
  // all of which are salvaged as separate cookies.
  const expand = (o) => {
    if (!o || typeof o !== 'object') return [];
    const c = {
      name: o.name == null ? '' : String(o.name),
      value: o.value == null ? '' : String(o.value),
    };
    if (o.domain) c.domain = String(o.domain);
    if (o.path) c.path = String(o.path);
    if (o.secure != null) c.secure = !!o.secure;
    if (o.httpOnly != null) c.httpOnly = !!o.httpOnly;
    if (o.sameSite) c.sameSite = String(o.sameSite);
    let exp = Number(o.expirationDate != null ? o.expirationDate : o.expires);
    if (Number.isFinite(exp) && exp > 1e12) exp = exp / 1000; // ms -> s
    if (exp > 0) c.expirationDate = exp;
    if (o.session === true) c.expirationDate = undefined;

    let extras = [];
    // --- repair malformed exports ---
    if (c.domain && !looksLikeDomain(c.domain)) {
      // Hand-built / mangled exports sometimes put "name=value" (or a whole
      // "a=1; b=2" chain) in the domain field. Salvage ALL clean pairs,
      // prefer the one matching the object's own name, then ALWAYS drop the
      // non-hostname domain (fall back to host-only).
      const pairs = salvagePairsFromGarbage(c.domain);
      delete c.domain;
      if (pairs.length) {
        const match = pairs.find((p) => p.name === c.name);
        const first = match || pairs[0];
        if (!c.name) c.name = first.name;
        if (!c.value) c.value = first.value;
        extras = pairs.filter((p) => p !== first);
      }
    }
    if (!c.name) return extras; // nothing usable without a name
    c.value = sanitizeCookieValue(c.value);
    if (typeof c.value === 'string' && c.value) {
      // value double-wrapped as "CookieName=value" -> unwrap
      const esc = c.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const pm = new RegExp('^' + esc + '=(.+)$').exec(c.value);
      if (pm) c.value = pm[1];
    }
    const main = { name: c.name, value: c.value };
    if (c.domain) main.domain = c.domain; // valid domains survive (only garbage is dropped)
    if (c.path) main.path = c.path;
    if (c.secure != null) main.secure = c.secure;
    if (c.httpOnly != null) main.httpOnly = c.httpOnly;
    if (c.sameSite) main.sameSite = c.sameSite;
    if (c.expirationDate > 0) main.expirationDate = c.expirationDate;
    return [main, ...extras];
  };
  if (Array.isArray(j)) {
    return j.map(expand).flat().filter(Boolean);
  }
  if (j && typeof j === 'object') {
    // single cookie object
    if (j.name || (j.domain && !looksLikeDomain(j.domain))) {
      return expand(j);
    }
    // map form: {name: value, ...}
    return Object.entries(j)
      .filter(([k]) => k && typeof k === 'string')
      .map(([k, v]) => ({ name: k, value: v == null ? '' : String(v) }));
  }
  return [];
}

function parseHeaderCookies(t) {
  const out = [];
  const seen = new Set();
  for (const piece of t.split(/[;\n]+/)) {
    const p = piece.trim();
    if (!p) continue;
    const eq = p.indexOf('=');
    if (eq <= 0) continue;
    const name = p.slice(0, eq).trim();
    const value = sanitizeCookieValue(p.slice(eq + 1));
    if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name)) continue;
    if (!value) continue;
    const key = name + '=' + value;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ name, value });
  }
  return out;
}
