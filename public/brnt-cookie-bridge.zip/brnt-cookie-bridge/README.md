# BRNT Cookie Bridge

Companion browser extension for the **BRNT LoginProbe** console
(`https://p1pyx8cst561-d.space-z.ai`).

**v1.6.0** makes the popup **current-page-first**: the "Site to open" field
is GONE. The Bridge now always imports cookies into the site you are on —
the **active tab** is the target. A new **One-click import** button sets the
cookies and reloads the tab logged-in in a single click; if the current tab
is a different site (or a new-tab page), the cookie's own site opens in a
new tab automatically. No URL typing, ever.

**v1.5.0** fixes the "Applied 0/1 cookies" class and understands **native
Netflix links**: (1) cookie values are sanitized everywhere — Chrome rejects
values containing `;`, so trailing semicolons / glued pairs / quotes from
hand-built JSON are stripped automatically; (2) garbage `domain` fields now
salvage ALL pairs they contain (`"NetflixId=…; SecureNetflixId=…"` becomes
two cookies); (3) pasting a native `?nftoken=` link (raw token, no `BR1.`)
shows a red **Open & sign in** button — Netflix's own server logs you in,
no cookie applying needed.

**v1.4.0** accepts **magic links pasted into the popup**: copy the console's
`https://…/?nftoken=…` link, paste it in the cookie box and hit Apply — the
popup decodes the token and logs you in without opening the link first
(opening it in the address bar still works too). It also understands
DevTools-style `Cookie:` / `Set-Cookie:` header lines now.

**v1.3.0** adds **auto-repair for malformed cookie exports**: if a JSON
export carries junk in the `domain` field (e.g. a whole `Name=value` pair
instead of a hostname), the popup now drops it, keeps the cookie as
host-only, warns you and never poisons the "Site to open" field again.
The header also shows the real version from the manifest.

**v1.2.0** adds **magic links**: links shaped like Netflix's own
`https://netflix.com/?nftoken=…` that carry the session inside the URL. Open
one anywhere and the extension applies the cookies, strips the token and
reloads — you land logged-in on the real site.

Browsers do not let a web page set cookies on another site's domain, so the
console can show you the cookies but cannot inject them into the real website.
This extension has the privileged `chrome.cookies` access needed to do it:
it **applies your captured login cookies to the real site and opens it
logged-in**, in one click. Cookies persist in your browser profile
(permanent until they expire or you clear them).

## Install (one-time, ~30 seconds)

1. Download `brnt-cookie-bridge.zip` and **unzip it** (you get a
   `brnt-cookie-bridge` folder).
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (toggle, top-right).
4. Click **Load unpacked** and select the unzipped `brnt-cookie-bridge`
   folder.
5. (Optional) Pin it: puzzle-piece icon in the toolbar -> pin
   **BRNT Cookie Bridge**.

Works in Chrome, Edge, Brave, and other Chromium browsers.

## Use (per session)

1. In the LoginProbe console, run a check that succeeds (or take the
   `.txt` cookie file you originally uploaded).
2. Click the **BRNT Cookie Bridge** icon.
3. Get the cookies into the popup — any of these works:
   - **Load .txt / .json file** — pick the same cookie file you uploaded,
   - **Paste from clipboard** — copy cookies from anywhere first, or
   - paste manually into the box (Netscape cookies.txt, Cookie-Editor
     JSON, JSON object, or a header string `name=value; name2=value2`).
4. Open the target site in a tab (if you are not already on it).
5. Click **One-click import** — cookies go straight into the current tab's
   site and the tab reloads, already logged in. The target line in the
   popup always shows where the cookies will land:
   - green **CURRENT TAB** — the tab you are on is the cookie's site,
   - amber **NEW TAB** — the cookie's own site opens in a new tab
     (you are on a different site or a new-tab page).
   Prefer a fresh tab anyway? Use **Import & open site in new tab**.

All cookie attributes are honoured: `httpOnly`, `secure`, `domain`
(including parent-domain cookies like `.amazon.com`), `path`,
`sameSite`, and expiry (persistent cookies survive browser restarts).

## Magic links (nftoken)

In the console's result dialog, **Share logged-in link (nftoken)** builds a
link like:

```
https://www.netflix.com/?nftoken=BR1.<encoded session cookies>
```

- The payload is the session cookie jar compressed (deflate, `BR1.` prefix;
  `BR0.` = uncompressed fallback) and base64url-encoded, so it survives
  copy/paste and messengers.
- Open the link in ANY tab of a browser with BRNT Cookie Bridge v1.2+:
  the extension decodes it, applies every cookie (httpOnly / domain /
  expiry included), removes `?nftoken=` from the address bar and reloads.
- `?brnttoken=` works as an alias for sites that choke on the parameter.
- ⚠️ The link **contains the live session** — treat it like a password.
  It stops working when the server-side session dies.

## One-click mode (console -> extension)

The extension listens for automation requests from allowed console origins
(`https://*.space-z.ai`, `http://localhost:3000`) via
`chrome.runtime.sendMessage`:

- `BRNT_PING` -> `{ok: true, name, version}`
- `BRNT_APPLY` with `{url, cookies, open}` -> applies cookies, opens the site

This means when the console is updated with an "Open real site" button, no
further extension changes are needed — the bridge is already wired.

## Files

- `manifest.json` — MV3 manifest, permissions, allowed console origins
- `shared.js` — cookie parsing (Netscape / JSON / header) + nftoken codec + set-fallback logic
- `popup.js` / `popup.html` — the popup UI
- `background.js` — external message handler (one-click) + nftoken navigation interceptor
- `icons/` — extension icons

## Troubleshooting

- **Pasted the magic link into the popup and nothing happened** — update to
  v1.4+: the popup now decodes a pasted `?nftoken=` link itself. Or just open
  the link directly in the address bar (any tab) with the Bridge installed.
- **"Applied 0/N cookies"** — one of three causes:
  1. The pasted JSON has a bad `domain` value (a `Name=value` string instead
     of a hostname). v1.3+ auto-repairs this — update the extension.
  2. You pasted only ONE cookie of a multi-cookie session. Netflix needs
     **both `NetflixId` and `SecureNetflixId`**; most sites need the full set.
     In Cookie-Editor use **Export all**, not a single cookie.
  3. You are importing into the wrong tab — the target line in the popup
     shows the site the cookies will land on; open that site in a tab and
     import again (or use **Import & open site in new tab**).
- **"This extension may have been corrupted"** — re-download the zip and
  unzip with a real unzip tool (some managers wrap folders).
- **Cookies apply but site still logs out** — some sites bind sessions to
  IP or device fingerprints; re-check the session in the console first,
  then copy the *fresh* cookies.
- **Wrong site is targeted** — v1.6+ picks the site from your ACTIVE TAB
  and the cookie domains. Green target = current tab, amber = the cookie's
  own site opens in a new tab. Just open the site you want first.
