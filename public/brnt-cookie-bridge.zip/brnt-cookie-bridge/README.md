# BRNT Cookie Bridge

Companion browser extension for the **BRNT LoginProbe** console
(`https://p1pyx8cst561-d.space-z.ai`).

**v1.2.0** adds **magic links**: links shaped like Netflix's own
`https://netflix.com/?nftoken=…` that carry the session inside the URL. Open
one anywhere and the extension applies the cookies, strips the token and
reloads — you land logged-in on the real site.

Browsers do not let a web page set cookies on another site's domain, so the
console can show you the cookies but cannot inject them into the real website.
This extension has the privileged `chrome.cookies` access needed to do it:
it **applies your captured login cookies to the real site and opens it
logged-in**, in one click. Cookies persist in your browser profile
(permanent until they expire or you clear them).

## Install (one-time, ~30 seconds)

1. Download `brnt-cookie-bridge.zip` and **unzip it** (you get a
   `brnt-cookie-bridge` folder).
2. Open Chrome and go to `chrome://extensions`.
3. Turn on **Developer mode** (toggle, top-right).
4. Click **Load unpacked** and select the unzipped `brnt-cookie-bridge`
   folder.
5. (Optional) Pin it: puzzle-piece icon in the toolbar -> pin
   **BRNT Cookie Bridge**.

Works in Chrome, Edge, Brave, and other Chromium browsers.

## Use (per session)

1. In the LoginProbe console, run a check that succeeds (or take the
   `.txt` cookie file you originally uploaded).
2. Click the **BRNT Cookie Bridge** icon.
3. Get the cookies into the popup — any of these works:
   - **Load .txt / .json file** — pick the same cookie file you uploaded,
   - **Paste from clipboard** — copy cookies from anywhere first, or
   - paste manually into the box (Netscape cookies.txt, Cookie-Editor
     JSON, JSON object, or a header string `name=value; name2=value2`).
4. The **Site to open** field auto-fills from the cookie domains — fix it
   if needed.
5. Click **Apply & open site** — a new tab opens the real website,
   already logged in. Or use **Apply & reload current tab** if you are
   already on the site.

All cookie attributes are honoured: `httpOnly`, `secure`, `domain`
(including parent-domain cookies like `.amazon.com`), `path`,
`sameSite`, and expiry (persistent cookies survive browser restarts).

## Magic links (nftoken)

In the console's result dialog, **Share logged-in link (nftoken)** builds a
link like:

```
https://www.netflix.com/?nftoken=BR1.<encoded session cookies>
```

- The payload is the session cookie jar compressed (deflate, `BR1.` prefix;
  `BR0.` = uncompressed fallback) and base64url-encoded, so it survives
  copy/paste and messengers.
- Open the link in ANY tab of a browser with BRNT Cookie Bridge v1.2+:
  the extension decodes it, applies every cookie (httpOnly / domain /
  expiry included), removes `?nftoken=` from the address bar and reloads.
- `?brnttoken=` works as an alias for sites that choke on the parameter.
- ⚠️ The link **contains the live session** — treat it like a password.
  It stops working when the server-side session dies.

## One-click mode (console -> extension)

The extension listens for automation requests from allowed console origins
(`https://*.space-z.ai`, `http://localhost:3000`) via
`chrome.runtime.sendMessage`:

- `BRNT_PING` -> `{ok: true, name, version}`
- `BRNT_APPLY` with `{url, cookies, open}` -> applies cookies, opens the site

This means when the console is updated with an "Open real site" button, no
further extension changes are needed — the bridge is already wired.

## Files

- `manifest.json` — MV3 manifest, permissions, allowed console origins
- `shared.js` — cookie parsing (Netscape / JSON / header) + nftoken codec + set-fallback logic
- `popup.js` / `popup.html` — the popup UI
- `background.js` — external message handler (one-click) + nftoken navigation interceptor
- `icons/` — extension icons

## Troubleshooting

- **"This extension may have been corrupted"** — re-download the zip and
  unzip with a real unzip tool (some managers wrap folders).
- **Cookies apply but site still logs out** — some sites bind sessions to
  IP or device fingerprints; re-check the session in the console first,
  then copy the *fresh* cookies.
- **Wrong site opens** — clear the *Site to open* field and type the URL
  you want; the auto-fill picks the most specific cookie domain.
