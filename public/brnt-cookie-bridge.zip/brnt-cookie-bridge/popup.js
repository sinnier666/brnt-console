// BRNT Cookie Bridge - popup logic (v1.6.0).
// Parses cookies and imports them into the site the user is ALREADY on:
// the active tab is the target — there is no manual site field anymore.
// One click = cookies set + current tab reloaded logged-in (or the cookie
// site auto-opens in a new tab when the current tab is something else).

import {
  parseCookieText,
  resolveImportTarget,
  buildSetAttempts,
  extractMagicToken,
  extractNativeLink,
  decodeMagicTokenSmart,
} from './shared.js';

const $ = (id) => document.getElementById(id);

const hasChrome = typeof chrome !== 'undefined' && !!(chrome.cookies && chrome.tabs && chrome.storage);
let cookies = [];
let activeTabUrl = ''; // URL of the tab the popup was opened on (the import target)
let magic = null; // decoded ?nftoken= payload {u, c} when a magic link was pasted
let magicToken = ''; // last token we attempted to decode
let magicBusy = false;
let nativeLink = null; // {token, url} when a NATIVE Netflix nftoken was pasted
let target = { url: null, mode: 'current-tab', matched: false, reason: '' };

// ---------- helpers ----------

function setStatus(msg, kind = 'info') {
  const s = $('status');
  s.textContent = msg;
  s.className = kind;
}

function currentList() {
  return cookies.length ? cookies : magic && magic.c ? magic.c : [];
}

function hostOf(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

function renderTarget() {
  const row = $('targetRow');
  const txt = $('targetText');
  const mode = $('targetMode');
  const list = currentList();

  target = resolveImportTarget({
    magicUrl: magic && magic.u ? magic.u : null,
    activeTabUrl,
    cookies: list,
  });

  if (!list.length) {
    // Nothing pasted yet — show where cookies WOULD go.
    const h = hostOf(activeTabUrl);
    txt.textContent = h ? `Import into: ${h} (current tab)` : 'Import into: current tab';
    mode.textContent = '';
    row.className = 'target';
    return;
  }
  if (!target.url) {
    txt.textContent = target.reason;
    mode.textContent = '';
    row.className = 'target move';
    return;
  }
  const h = hostOf(target.url);
  txt.textContent = 'Import into: ';
  const b = document.createElement('b');
  b.textContent = h;
  txt.appendChild(b);
  if (target.matched) {
    mode.textContent = 'current tab';
    row.className = 'target ok';
  } else {
    mode.textContent = 'new tab';
    row.className = 'target move';
  }
  if (target.reason) row.title = target.reason;
}

function refresh() {
  const raw = $('cookies').value.trim();
  let r = { format: null, cookies: [] };
  try {
    r = raw ? parseCookieText(raw) : r;
  } catch {
    /* keep empty */
  }
  cookies = r.cookies || [];

  // ---- magic link detection (?nftoken= / ?brntoken= pasted as text) ----
  const token = raw ? extractMagicToken(raw) : null;
  nativeLink = raw && !token ? extractNativeLink(raw) : null;
  if (!token) {
    magic = null;
    magicToken = '';
  } else if (token !== magicToken && !magicBusy) {
    magicBusy = true;
    magicToken = token;
    decodeMagicTokenSmart(token)
      .then((p) => {
        magic = p;
      })
      .catch(() => {
        magic = null;
      })
      .finally(() => {
        magicBusy = false;
        refresh();
      });
  }

  // target must be resolved BEFORE the preview text below (it reads target.url)
  renderTarget();

  const prev = $('preview');

  if (magic) {
    const host = hostOf(magic.u || '');
    prev.textContent = `Magic link detected - ${magic.c.length} cookies${host ? ` for ${host}` : ''} - click One-click import to log in (no need to open the link separately)`;
    prev.className = 'preview ok';
  } else if (token) {
    prev.textContent = 'Magic link (?nftoken=) detected but it is invalid, truncated or corrupted.';
    prev.className = 'preview warn';
  } else if (nativeLink) {
    // NATIVE Netflix token: Netflix's own server does the login — nothing to apply.
    prev.textContent = 'Netflix-native login link detected - you do NOT need this popup: click "Open & sign in" below (or open the link in the address bar) and Netflix itself logs you in. No cookies to apply.';
    prev.className = 'preview ok';
  } else if (cookies.length) {
    const domains = [...new Set(cookies.map((c) => c.domain || '(host-only)'))].slice(0, 3).join(', ');
    let hint = '';
    if (!cookies.some((c) => c.domain)) {
      hint += ' | no domain info in these cookies - open the target site in a tab first, then import';
    }
    const targetHost = target.url ? hostOf(target.url) : '';
    if (targetHost.endsWith('netflix.com')) {
      const names = new Set(cookies.map((c) => c.name));
      if (!names.has('NetflixId') || !names.has('SecureNetflixId')) {
        hint += ' | Netflix needs BOTH NetflixId + SecureNetflixId - use "Export all" in Cookie-Editor';
      }
    }
    prev.textContent = `${cookies.length} cookie(s) detected - ${r.format} - domain: ${domains}${hint}`;
    prev.className = hint ? 'preview warn' : 'preview ok';
  } else if (raw) {
    prev.textContent = 'No cookies recognised yet - supported: Netscape cookies.txt, JSON, header string, or a ?nftoken= magic link.';
    prev.className = 'preview';
  } else {
    prev.textContent = 'Paste cookies above...';
    prev.className = 'preview';
  }

  const canApply = Boolean(currentList().length) && hasChrome && Boolean(target.url);
  $('applyQuick').disabled = !canApply;
  $('applyNewTab').disabled = !canApply;
  $('openNative').hidden = !nativeLink || !hasChrome;
}

async function openNative() {
  if (!nativeLink) return;
  try {
    await chrome.tabs.create({ url: nativeLink.url, active: true });
    setStatus('Opening the native Netflix login link - Netflix signs you in.', 'ok');
    window.close();
  } catch (e) {
    setStatus('Could not open the tab (' + ((e && e.message) || e) + '). Open the link manually.', 'err');
  }
}

function rememberSave() {
  if (!hasChrome || !$('remember').checked) return;
  try {
    chrome.storage.local.set({ lastCookies: $('cookies').value });
  } catch {
    /* ignore */
  }
}

async function setOne(c, baseUrl) {
  let lastErr = null;
  for (const details of buildSetAttempts(c, baseUrl)) {
    try {
      const r = await chrome.cookies.set(details);
      if (r) return r;
      lastErr = new Error('chrome.cookies.set returned null');
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('unknown error');
}

async function apply(mode) {
  // mode: 'oneclick' = smart (reload current tab when it is the target,
  //       otherwise open the target in a new tab) | 'newtab' = always new tab
  if (!hasChrome) {
    setStatus('Extension APIs unavailable - load the unpacked extension first.', 'err');
    return;
  }
  const list = currentList();
  if (!list.length) {
    setStatus('No cookies to apply.', 'err');
    return;
  }
  if (!target.url) {
    setStatus(target.reason || 'No target site - open the site in a tab first.', 'err');
    return;
  }
  const base = target.url;
  const host = hostOf(base);

  rememberSave();
  let set = 0;
  const failed = [];
  for (const c of list) {
    try {
      await setOne(c, base);
      set++;
    } catch (e) {
      failed.push(`${c.name}: ${(e && e.message) || e}`);
    }
  }

  if (failed.length) {
    $('errBox').hidden = false;
    $('errList').textContent = failed.join('\n');
    setStatus(
      `Applied ${set}/${list.length} cookies into ${host}. Tip: re-export the FULL cookie set (Cookie-Editor -> Export all) and make sure the tab is on the cookie's own site.`,
      'err'
    );
    return;
  }

  // 'newtab' always opens a tab; 'oneclick' reloads in place when the active
  // tab IS the target site, otherwise opens the target in a new tab.
  let openNew = mode === 'newtab' || !target.matched;
  if (mode === 'oneclick' && !openNew) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.url || !/^https?:/i.test(tab.url)) {
        openNew = true; // tab vanished / navigated while the popup was open
      } else if (hostOf(tab.url) !== host) {
        openNew = true; // user switched tabs meanwhile - do not reload the wrong site
      }
    } catch {
      openNew = true;
    }
  }

  try {
    if (openNew) {
      setStatus(`Applied ${set} cookie(s) - opening ${host}`, 'ok');
      await chrome.tabs.create({ url: base, active: true });
    } else {
      setStatus(`Applied ${set} cookie(s) - reloading ${host} logged-in...`, 'ok');
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await chrome.tabs.reload(tab.id);
    }
    window.close();
  } catch (e) {
    setStatus(`Cookies applied into ${host}, but the tab action failed: ` + ((e && e.message) || e), 'info');
  }
}

// ---------- wiring ----------

$('cookies').addEventListener('input', refresh);

$('pasteBtn').addEventListener('click', async () => {
  try {
    const txt = await navigator.clipboard.readText();
    if (txt) {
      $('cookies').value = txt.trim();
      refresh();
    } else {
      setStatus('Clipboard is empty.', 'info');
    }
  } catch (e) {
    setStatus('Clipboard read failed (' + ((e && e.message) || e) + '). Paste manually instead.', 'err');
  }
});

$('loadFile').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', async () => {
  const f = $('fileInput').files && $('fileInput').files[0];
  if (!f) return;
  try {
    const txt = await f.text();
    $('cookies').value = txt;
    refresh();
    setStatus(`Loaded ${f.name}.`, 'ok');
  } catch (e) {
    setStatus('Could not read file: ' + ((e && e.message) || e), 'err');
  }
});

$('applyQuick').addEventListener('click', () => apply('oneclick'));
$('applyNewTab').addEventListener('click', () => apply('newtab'));
$('openNative').addEventListener('click', openNative);

// init: extension status banner + restore last session
(function init() {
  if (!hasChrome) {
    $('hdr').classList.add('off');
    $('banner').style.display = 'block';
    setStatus('Extension mode off (viewing popup.html outside chrome).', 'info');
    refresh();
    return;
  }
  // show the REAL version from the manifest (the static label can go stale)
  try {
    $('ver').textContent = 'v' + chrome.runtime.getManifest().version;
  } catch {
    /* keep static */
  }
  // the ACTIVE tab decides where cookies are imported - capture it first
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const t = tabs && tabs[0];
    if (t && t.url && /^https?:/i.test(t.url)) activeTabUrl = t.url;
    refresh();
  });
  chrome.storage.local.get(['lastCookies'], (st) => {
    if (st && st.lastCookies && !$('cookies').value) {
      $('cookies').value = st.lastCookies;
    }
    refresh();
  });
  refresh();
})();
