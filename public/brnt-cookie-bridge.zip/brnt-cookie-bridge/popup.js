// BRNT Cookie Bridge - popup logic.
// Parses cookies, applies them to the target site via chrome.cookies
// (with progressive fallback), then opens/reloads the site.

import { parseCookieText, deriveSiteUrl, normalizeUrl, buildSetAttempts } from './shared.js';

const $ = (id) => document.getElementById(id);

const hasChrome = typeof chrome !== 'undefined' && !!(chrome.cookies && chrome.tabs && chrome.storage);
let cookies = [];
let urlTouched = false; // stop auto-filling once the user edits the URL

// ---------- helpers ----------

function setStatus(msg, kind = 'info') {
  const s = $('status');
  s.textContent = msg;
  s.className = kind;
}

function refresh() {
  const raw = $('cookies').value.trim();
  let r = { format: null, cookies: [] };
  try {
    r = raw ? parseCookieText(raw) : r;
  } catch {
    /* keep empty */
  }
  cookies = r.cookies || [];

  const prev = $('preview');
  if (cookies.length) {
    const domains = [...new Set(cookies.map((c) => c.domain || '(host-only)'))].slice(0, 3).join(', ');
    prev.textContent = `${cookies.length} cookie(s) detected - ${r.format} - domain: ${domains}`;
    prev.className = 'preview ok';
  } else if (raw) {
    prev.textContent = 'No cookies recognised yet - supported: Netscape cookies.txt, JSON, header string.';
    prev.className = 'preview';
  } else {
    prev.textContent = 'Paste cookies above...';
    prev.className = 'preview';
  }

  if (cookies.length && !urlTouched && !$('siteUrl').value) {
    const u = deriveSiteUrl(cookies);
    if (u) $('siteUrl').value = u;
  }

  $('applyOpen').disabled = !cookies.length || !hasChrome;
  $('applyTab').disabled = !cookies.length || !hasChrome;
}

function rememberSave() {
  if (!hasChrome || !$('remember').checked) return;
  try {
    chrome.storage.local.set({
      lastCookies: $('cookies').value,
      lastUrl: $('siteUrl').value,
    });
  } catch {
    /* ignore */
  }
}

async function setOne(c, baseUrl) {
  let lastErr = null;
  for (const details of buildSetAttempts(c, baseUrl)) {
    try {
      const r = await chrome.cookies.set(details);
      if (r) return r;
      lastErr = new Error('chrome.cookies.set returned null');
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('unknown error');
}

async function apply(mode) {
  if (!hasChrome) {
    setStatus('Extension APIs unavailable - load the unpacked extension first.', 'err');
    return;
  }
  let base;
  try {
    base = normalizeUrl($('siteUrl').value);
  } catch (e) {
    setStatus('Enter a valid site URL (' + e.message + ').', 'err');
    return;
  }
  if (!cookies.length) {
    setStatus('No cookies to apply.', 'err');
    return;
  }

  rememberSave();
  let set = 0;
  const failed = [];
  for (const c of cookies) {
    try {
      await setOne(c, base);
      set++;
    } catch (e) {
      failed.push(`${c.name}: ${(e && e.message) || e}`);
    }
  }

  if (failed.length) {
    $('errBox').hidden = false;
    $('errList').textContent = failed.join('\n');
    setStatus(`Applied ${set}/${cookies.length} cookies - see failed list.`, 'err');
    return;
  }

  if (mode === 'open') {
    setStatus(`Applied ${set} cookie(s) - opening ${base}`, 'ok');
    rememberSave();
    try {
      await chrome.tabs.create({ url: base, active: true });
      window.close();
    } catch (e) {
      setStatus('Cookies applied, but could not open a tab: ' + ((e && e.message) || e), 'info');
    }
    return;
  }

  // mode === 'tab': reload current tab if it is on the target site, otherwise navigate it
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const sameHost = tab && tab.url && new URL(tab.url).host === new URL(base).host;
    if (sameHost) {
      await chrome.tabs.reload(tab.id);
    } else {
      await chrome.tabs.update(tab.id, { url: base });
    }
    setStatus(`Applied ${set} cookie(s) - ${sameHost ? 'reloaded current tab.' : 'navigated current tab.'}`, 'ok');
  } catch (e) {
    setStatus(`Applied ${set} cookie(s), but tab action failed: ` + ((e && e.message) || e), 'info');
  }
}

// ---------- wiring ----------

$('cookies').addEventListener('input', refresh);
$('siteUrl').addEventListener('input', () => {
  urlTouched = true;
});

$('pasteBtn').addEventListener('click', async () => {
  try {
    const txt = await navigator.clipboard.readText();
    if (txt) {
      $('cookies').value = txt.trim();
      refresh();
    } else {
      setStatus('Clipboard is empty.', 'info');
    }
  } catch (e) {
    setStatus('Clipboard read failed (' + ((e && e.message) || e) + '). Paste manually instead.', 'err');
  }
});

$('loadFile').addEventListener('click', () => $('fileInput').click());
$('fileInput').addEventListener('change', async () => {
  const f = $('fileInput').files && $('fileInput').files[0];
  if (!f) return;
  try {
    const txt = await f.text();
    $('cookies').value = txt;
    urlTouched = false;
    $('siteUrl').value = '';
    refresh();
    setStatus(`Loaded ${f.name}.`, 'ok');
  } catch (e) {
    setStatus('Could not read file: ' + ((e && e.message) || e), 'err');
  }
});

$('applyOpen').addEventListener('click', () => apply('open'));
$('applyTab').addEventListener('click', () => apply('tab'));

// init: extension status banner + restore last session
(function init() {
  if (!hasChrome) {
    $('hdr').classList.add('off');
    $('banner').style.display = 'block';
    setStatus('Extension mode off (viewing popup.html outside chrome).', 'info');
    return;
  }
  // prefill URL from the active tab when it plausibly matches (helps "reload current tab")
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const t = tabs && tabs[0];
    if (t && t.url && /^https?:/i.test(t.url)) {
      try {
        const u = new URL(t.url);
        $('siteUrl').placeholder = u.origin + '/';
        $('siteUrl').dataset.activeTab = u.origin + '/';
      } catch {
        /* ignore */
      }
    }
  });
  chrome.storage.local.get(['lastCookies', 'lastUrl'], (st) => {
    if (st && st.lastCookies && !$('cookies').value) {
      $('cookies').value = st.lastCookies;
    }
    if (st && st.lastUrl && !$('siteUrl').value) {
      $('siteUrl').value = st.lastUrl;
      urlTouched = true;
    }
    refresh();
  });
  // if active tab host matches the cookie domains, prefer its origin for apply-tab flow
  $('cookies').addEventListener('input', () => {
    const at = $('siteUrl').dataset.activeTab;
    if (!at) return;
    try {
      const tabHost = new URL(at).hostname;
      const match = cookies.some((c) => {
        const d = (c.domain || '').replace(/^\./, '');
        return d && (tabHost === d || tabHost.endsWith('.' + d));
      });
      if (match) $('siteUrl').value = at;
    } catch {
      /* ignore */
    }
  });
  refresh();
})();
