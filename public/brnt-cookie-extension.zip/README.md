# BRNT Cookie Importer (companion extension)

One click in BRNT LoginProbe → the session's cookies are planted on the real
site through the privileged `chrome.cookies` API and the original URL opens —
already logged in. No clipboard, no Cookie-Editor, no pasting.

## Why an extension?

Browsers forbid a web page from setting cookies for a DIFFERENT site (that is
why LoginProbe itself can never log you in on the real URL directly). An
extension with the `cookies` permission is the one legitimate way to automate
the import — this tiny worker does exactly that and nothing else.

## Install (once, ~30 seconds) — Chrome / Edge / Brave

1. Download `brnt-cookie-extension.zip` from the console (or use this folder)
   and unzip it.
2. Open `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped `extension` folder.
5. Back in LoginProbe, click a successful target — the site opens logged in.

The extension only listens on the LoginProbe console origins (localhost /
*.space-z.ai). On any other page its popup offers "Paste & apply" + "Re-apply
last" as a generic manual importer.

## Files

- `manifest.json` — MV3; permissions: `cookies`, `clipboardRead`, `storage`.
- `background.js` — plants cookies via `chrome.cookies.set`, optionally opens
  the original URL, remembers the last payload for the popup.
- `content.js` — relay on console origins: page postMessage ⇄ background.
- `popup.html/js` — manual fallback: paste JSON / header / [name,value] pairs,
  or re-apply the last payload anywhere.

## Handshake (for debugging)

- page → `BRNT_EXTENSION_PING` → content script answers `BRNT_EXTENSION_HERE`
- page → `BRNT_APPLY_COOKIES {requestId, url?, cookies[]}`
- bg → `BRNT_APPLY_COOKIES_RESULT {requestId, ok, applied, errors?}`
