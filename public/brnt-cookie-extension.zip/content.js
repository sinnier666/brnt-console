/**
 * BRNT Cookie Importer — content script.
 *
 * Lives only on the BRNT console origins (localhost / *.space-z.ai) and is the
 * relay between the page and the privileged background worker:
 *
 *   page  → window.postMessage  BRNT_EXTENSION_PING
 *   here  → window.postMessage  BRNT_EXTENSION_HERE          (announce)
 *   page  → window.postMessage  BRNT_APPLY_COOKIES {url, cookies, requestId}
 *   here  → chrome.runtime.sendMessage → background plants the cookies
 *   here  → window.postMessage  BRNT_APPLY_COOKIES_RESULT {requestId, ok, applied}
 *
 * The page never touches chrome.* — this relay is the whole bridge.
 */
(() => {
  const NAMESPACE = "brnt-cookie-import";
  if (window.__brntCookieImporter) return;
  window.__brntCookieImporter = true;

  const announce = () => {
    try {
      window.postMessage({ namespace: NAMESPACE, type: "BRNT_EXTENSION_HERE" }, window.location.origin);
    } catch {
      /* page navigating — ignore */
    }
  };

  // Announce immediately (covers "extension loaded after page") and answer
  // every ping (covers "page loaded before extension / SW woke up").
  announce();

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.namespace !== NAMESPACE) return;

    if (msg.type === "BRNT_EXTENSION_PING") {
      announce();
      return;
    }

    if (msg.type === "BRNT_APPLY_COOKIES") {
      let resp;
      try {
        // Extension context can be invalidated right after an update — surface
        // that to the page instead of leaving it waiting for the timeout.
        resp = chrome.runtime.sendMessage(msg);
      } catch (e) {
        window.postMessage(
          {
            namespace: NAMESPACE,
            type: "BRNT_APPLY_COOKIES_RESULT",
            requestId: msg.requestId,
            ok: false,
            applied: 0,
            errors: [String(e?.message || e)],
          },
          window.location.origin,
        );
        return;
      }
      resp
        .then((res) => {
          window.postMessage(
            {
              namespace: NAMESPACE,
              type: "BRNT_APPLY_COOKIES_RESULT",
              requestId: msg.requestId,
              ok: !!res?.ok,
              applied: res?.applied ?? 0,
              errors: res?.errors ?? [],
              opened: res?.opened ?? null,
            },
            window.location.origin,
          );
        })
        .catch((e) => {
          window.postMessage(
            {
              namespace: NAMESPACE,
              type: "BRNT_APPLY_COOKIES_RESULT",
              requestId: msg.requestId,
              ok: false,
              applied: 0,
              errors: [String(e?.message || e)],
            },
            window.location.origin,
          );
        });
    }
  });
})();
