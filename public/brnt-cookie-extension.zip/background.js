/**
 * BRNT Cookie Importer — background service worker.
 *
 * Receives { type:"BRNT_APPLY_COOKIES", url?, cookies } from the content
 * script (or the popup), plants every cookie on its own domain through the
 * privileged chrome.cookies API — something NO web page can do — and, when a
 * url is provided, opens it in a new tab: the site comes up already logged in.
 *
 * Cookie objects follow the Chrome cookie model:
 *   { name, value, domain?, hostOnly, path, secure, httpOnly, sameSite,
 *     expirationDate?, session }
 * hostOnly cookies omit `domain` so the URL's host is used exactly.
 */

const MAX_COOKIES = 300;

function cookieUrl(c) {
  const scheme = c.secure ? "https" : "http";
  const host = String(c.domain || "").replace(/^\./, "") || "localhost";
  const path = c.path || "/";
  return `${scheme}://${host}${path.startsWith("/") ? path : "/" + path}`;
}

function toChromeDetails(c) {
  const details = {
    name: String(c.name),
    value: String(c.value ?? ""),
    url: cookieUrl(c),
    path: c.path || "/",
    secure: c.secure === true,
    httpOnly: c.httpOnly === true,
  };
  // A domain cookie (`.site.com` or subdomain-flag TRUE) sets `domain`;
  // a host-only cookie must NOT set it or Chrome widens the scope.
  if (!c.hostOnly && c.domain) details.domain = String(c.domain);
  const exp = Number(c.expirationDate);
  if (!c.session && Number.isFinite(exp) && exp > 0) details.expirationDate = Math.floor(exp);
  const ss = c.sameSite;
  if (ss === "no_restriction" || ss === "lax" || ss === "strict") {
    // Chrome rejects SameSite=None on non-secure cookies — downgrade, never fail.
    details.sameSite = ss === "no_restriction" && !details.secure ? "lax" : ss;
  }
  return details;
}

async function setOne(c) {
  const details = toChromeDetails(c);
  try {
    await chrome.cookies.set(details);
    return true;
  } catch (e) {
    // Retry relaxed (drop sameSite/expiry) before giving up on this cookie.
    try {
      delete details.sameSite;
      delete details.expirationDate;
      await chrome.cookies.set(details);
      return true;
    } catch {
      console.warn("BRNT: could not set cookie", c.name, e?.message || e);
      return false;
    }
  }
}

async function applyCookies(msg) {
  const list = Array.isArray(msg?.cookies) ? msg.cookies.slice(0, MAX_COOKIES) : [];
  let applied = 0;
  const errors = [];
  for (const c of list) {
    if (!c || typeof c.name !== "string" || !c.name) continue;
    if (await setOne(c)) applied++;
  }

  let opened = null;
  if (applied > 0 && typeof msg.url === "string" && /^https?:\/\//i.test(msg.url)) {
    try {
      const tab = await chrome.tabs.create({ url: msg.url, active: true });
      opened = tab?.id ?? null;
    } catch (e) {
      errors.push(`open: ${e?.message || e}`);
    }
  }

  // Remember the payload so the popup can re-apply without a new copy.
  try {
    if (applied > 0) {
      await chrome.storage.local.set({
        last: { at: Date.now(), url: msg.url ?? null, count: applied, cookies: list },
      });
    }
  } catch {
    /* storage is best-effort */
  }

  return { ok: applied > 0, applied, errors: errors.slice(0, 5), opened };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "BRNT_APPLY_COOKIES") return undefined;
  applyCookies(msg)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, applied: 0, errors: [String(e?.message || e)], opened: null }));
  return true; // async response
});
