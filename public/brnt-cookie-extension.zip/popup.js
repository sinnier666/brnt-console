/** BRNT Cookie Importer — popup: manual fallback importer. */

const NAMESPACE = "brnt-cookie-import";
const statusEl = document.getElementById("status");
const pasteBtn = document.getElementById("paste");
const againBtn = document.getElementById("again");

function show(text, cls) {
  statusEl.textContent = text;
  statusEl.className = cls || "";
}

async function readClipboard() {
  try {
    return await navigator.clipboard.readText();
  } catch {
    // execCommand("paste") still works in extension popups with clipboardRead.
    const ta = document.createElement("textarea");
    ta.value = "";
    document.body.appendChild(ta);
    ta.focus();
    let ok = false;
    try {
      ok = document.execCommand("paste");
    } catch {
      ok = false;
    }
    const text = ok ? ta.value : "";
    ta.remove();
    return text;
  }
}

/** Accepts our {url, cookies} payload, a plain cookie array (Cookie-Editor
 *  JSON), or an array of [name, value] pairs. */
function normalize(text) {
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    // Maybe a raw header string: "k=v; k2=v2"
    if (/^[\w.-]+\s*=/.test(text.trim()) && text.includes("=")) {
      const cookies = text
        .replace(/^\s*cookie\s*:\s*/i, "")
        .split(";")
        .map((frag) => {
          const eq = frag.indexOf("=");
          if (eq <= 0) return null;
          return { name: frag.slice(0, eq).trim(), value: frag.slice(eq + 1).trim() };
        })
        .filter(Boolean);
      return { url: null, cookies };
    }
    return null;
  }
  if (Array.isArray(data)) {
    // Cookie-Editor export: objects with name/value(+domain), or [name, value] pairs
    const cookies = data
      .map((item) => {
        if (Array.isArray(item) && item.length >= 2) return { name: item[0], value: item[1] };
        if (item && typeof item === "object" && (item.name || item.key)) {
          return { ...item, name: item.name ?? item.key, value: item.value ?? "" };
        }
        return null;
      })
      .filter(Boolean);
    return { url: null, cookies };
  }
  if (data && typeof data === "object" && Array.isArray(data.cookies)) {
    return { url: typeof data.url === "string" ? data.url : null, cookies: data.cookies };
  }
  return null;
}

function apply(payload, btn) {
  show("Applying…");
  btn.disabled = true;
  chrome.runtime
    .sendMessage({ type: "BRNT_APPLY_COOKIES", url: payload.url ?? undefined, cookies: payload.cookies })
    .then((res) => {
      btn.disabled = false;
      if (!res) {
        show("No answer from the background worker — reload the extension on chrome://extensions.", "err");
        return;
      }
      if (res.ok) {
        const where = payload.url ? " and opened the site" : " — refresh the site's tab to see the account";
        show(`✓ Applied ${res.applied} cookie${res.applied === 1 ? "" : "s"}${where}.`, "ok");
      } else {
        show(`Could not apply the cookies.${res.errors?.length ? "\n" + res.errors.join("\n") : ""}`, "err");
      }
    })
    .catch((e) => {
      btn.disabled = false;
      show(`Error: ${e?.message || e}`, "err");
    });
}

pasteBtn.addEventListener("click", async () => {
  const text = await readClipboard();
  if (!text) {
    show("Clipboard is empty or unreadable. Copy cookies from the BRNT console first.", "err");
    return;
  }
  const payload = normalize(text);
  if (!payload || payload.cookies.length === 0) {
    show("Clipboard does not contain cookies (expected JSON, [name,value] pairs or a k=v; k2=v2 header).", "err");
    return;
  }
  apply(payload, pasteBtn);
});

againBtn.addEventListener("click", async () => {
  const { last } = await chrome.storage.local.get("last");
  if (!last || !Array.isArray(last.cookies)) {
    show("Nothing to re-apply yet.", "err");
    return;
  }
  apply({ url: last.url, cookies: last.cookies }, againBtn);
});

// Enable "Re-apply last" when we have a stored payload.
chrome.storage.local.get("last").then(({ last }) => {
  if (last && Array.isArray(last.cookies) && last.cookies.length > 0) {
    const when = new Date(last.at).toLocaleTimeString();
    againBtn.disabled = false;
    againBtn.textContent = `Re-apply last (${last.count} cookies, ${when})`;
  }
});
